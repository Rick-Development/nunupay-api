<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Mail\SendMail;
use App\Models\User;
use App\Rules\PhoneLength;
use App\Traits\ApiResponse;
use App\Traits\Notify;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Password;
use App\Http\Controllers\API\PayscribeCustomerController;

class UserAuthController extends Controller
{
    use ApiResponse,Notify;
    private $bearer = 'eyJ0eXAiOiJKV1QiLCJrZXlJZCI6InZhc19qd3QiLCJhbGciOiJIUzUxMiJ9.eyJjbGllbnRJZCI6IlBLX1RFU1RfMkF1Znc0OXdjaSIsImFjY291bnRObyI6IjEwMTgwMDA2IiwiYXV0aG9yaXRpZXMiOlsiQklMTFNfUEFZTUVOVCIsIlRPUF9VUCJdLCJzdWIiOiJWQVNfVEVTVCIsImlzcyI6Ijlwc2IuY29tLm5nIiwiaWF0IjoxNjgwMDEwNjIyLCJqdGkiOiIyMzMzZWQ2MS02OTEyLTRkMzItYjVjZi1jYTkzNjFhZGJjY2IiLCJleHAiOjE2ODAwMTc4MjJ9.h9kb-ii-RZ-p9TjCbfhna8hAMbAfFTufCOhsu9Peh6MrZ28a2UuTr3vuHCDNYu0FPxqPlhLP0kFOo-1rCYB4eQ';

    private function strongPassword()
    {
        return Password::min(8)
            ->letters()
            ->mixedCase()
            ->numbers()
            ->symbols()
            ->uncompromised();
    }

    public function register(Request $request)
    {
        $basic = basicControl();
        $phoneCode = $request->input('phone_code');
        $registerRules = [
            'firstname' => 'required|string',
            'lastname' => 'required|string',
            'username' => 'required|string|alpha_dash|min:5|unique:users,username',
            'email' => 'required|string|email|unique:users,email',
            'password' => $basic->strong_password == 0 ?
                ['required', 'confirmed', 'min:6'] :
                ['required', 'confirmed', $this->strongPassword()],
            'password_confirmation' => 'required| min:6',
            'phone_code' => 'required|string',
            'phone' => ['required', 'numeric', 'unique:users,phone', new PhoneLength($phoneCode)],
            'country' => 'required|string',
            'country_code' => 'required|string',
        ];

        $message = [
            'password.letters' => 'password must be contain letters',
            'password.mixed' => 'password must be contain 1 uppercase and lowercase character',
            'password.symbols' => 'password must be contain symbols',
        ];

        $data = Validator::make($request->all(), $registerRules,$message);
        if ($data->fails()) {
            return response()->json($this->withError(collect($data->errors())->collapse()));
        }
        
        $customerId=  'no customer id';
        $tier = 0;
        
        $payscribeCustomerController = new PayscribeCustomerController();

    // Get the response as a JsonResponse object
    $res = $payscribeCustomerController->createCustomer($request);

    // Decode the response to access the data
    $responseData = $res->getData(true); // Convert to an associative array
        
          // Check if the response status is true and details exist
    if (isset($responseData['status']) && $responseData['status'] === true) {
        $details = $responseData['message']['details'] ?? [];
        $customerId = $details['customer_id'];
        $tier = $details['tier'];
        // return [
        //     'status' => 'success',
        //     'customer' => [
        //         'customer_id' => $details['customer_id'] ?? null,
        //         'first_name' => $details['first_name'] ?? null,
        //         'last_name' => $details['last_name'] ?? null,
        //         'email' => $details['email'] ?? null,
        //         'phone' => $details['phone'] ?? null,
        //         'country' => $details['country'] ?? null,
        //         'tier' => $details['tier'] ?? null,
        //         'created_at' => $details['created_at'] ?? null,
        //     ],
        // ];
    }else{
      
    // Handle the error case
    return response()->json([
        'status' => 'error',
        'message' => $responseData,
    ]);  
    }

        
        
        
        
        
        
        

        $sponsorId = null;
        if ($request->has('sponsor')) {
            $sponsor = User::where('username', $request->sponsor)
                ->where('email_verification', 1)
                ->where('sms_verification', 1)
                ->where('status', 1)
                ->first();
            $sponsorId = $sponsor ? $sponsor->id : null;
        }

        $user =  User::create([
            'firstname' => $request->firstname,
            'lastname' => $request->lastname,
            'username' => $request->username,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'phone' => $request->phone,
            'phone_code' => $request->phone_code,
            'country' => $request->country,
            'country_code' => $request->country_code,
            'email_verification' => ($basic->email_verification) ? 0 : 1,
            'sms_verification' => ($basic->sms_verification) ? 0 : 1,
            'remember_token' => Str::random(10),
            'referral_id' => $sponsorId,
            'payscribe_id' =>  $customerId,
            'tier' => $tier,
        ]);
        



        $this->sendWelcomeEmail($user);

       return response()->json([
    'status' => 'success',
    'message' => $user->createToken('token')->plainTextToken,
    'payscribe_id' => $customerId,
    'account_number' => $request->username,
    'user_pin' => $user->user_pin,
    'firstname' => $user->firstname
], 200);

    }

    public function login(Request $request)
    {
        try {
            $credentials = $request->only('username', 'password');

            $validator = Validator::make($credentials, [
                'username' => 'required|string',
                'password' => 'required|string',
            ]);

            if ($validator->fails()) {
                return response()->json($this->withError(collect($validator->errors())->collapse()));
            }
            $user = User::where('email', $credentials['username'])
                ->orWhere('username', $credentials['username'])
                ->first();


            if (!$user || !Hash::check($credentials['password'], $user->password)) {
                return response()->json($this->withError('credentials do not match'));
            }
            $data['message'] = 'User logged in successfully.';
            $data['token'] = $user->createToken($user->email)->plainTextToken;
            $data['payscribe_id'] = $user->payscribe_id;
            $data['account_number'] = $user->username;
            $data['user_pin'] = $user->user_pin;
            $data['firstname'] = $user->firstname;

            $this->loginNotify($user);

            //   return response()->json([
            //     'status' => 'success',
            //     'message' => $user->createToken('token')->plainTextToken,
            //     'payscribe_id' => payscribe_id,
            // ], 200);

            return response()->json($this->withSuccess($data));
        }catch (\Exception $e){
            return response()->json($this->withError($e->getMessage()));
        }
    }

    public function logout()
    {
        auth()->user()->tokens()->delete();
        return response()->json($this->withSuccess('User is logged out successfully'));
    }

    public function getEmailForRecoverPass(Request $request)
    {
        $validateUser = Validator::make($request->all(),
            [
                'email' => 'required|email',
            ]);

        if ($validateUser->fails()) {
            return response()->json($this->withError(collect($validateUser->errors())->collapse()));
        }

        try {
            $user = User::where('email', $request->email)->first();
            if (!$user) {
                return response()->json($this->withError('Email does not exit on record'));
            }

            $code = rand(10000, 99999);
            $data['email'] = $request->email;
            $data['message'] = 'OTP has been send';
            $user->verify_code = $code;
            $user->save();

            $basic = basicControl();
            $message = 'Your Password Recovery Code is ' . $code;
            $email_from = $basic->sender_email;
            @Mail::to($request->email)->send(new SendMail($email_from, "Recovery Code", $message));

            return response()->json($this->withSuccess($data));
        } catch (\Exception $e) {
            return response()->json($this->withError($e->getMessage()));
        }
    }

    public function getCodeForRecoverPass(Request $request)
    {
        $validateUser = Validator::make($request->all(),
            [
                'code' => 'required',
                'email' => 'required|email',
            ]);

        if ($validateUser->fails()) {
            return response()->json($this->withError(collect($validateUser->errors())->collapse()));
        }

        try {
            $user = User::where('email', $request->email)->first();
            if (!$user) {
                return response()->json($this->withError('Email does not exit on record'));
            }

            if ($user->verify_code == $request->code && $user->updated_at > Carbon::now()->subMinutes(5)) {
                $user->verify_code = null;
                $user->save();
                return response()->json($this->withSuccess('Code Matching'));
            }

            return response()->json($this->withError('Invalid Code'));
        } catch (\Exception $e) {
            return response()->json($this->withError($e->getMessage()));
        }
    }

    public function updatePass(Request $request)
    {
        $basic = basicControl();
        $rules = [
            'email' => 'required|email|exists:users,email',
            'password' => $basic->strong_password == 0 ?
                ['required', 'confirmed', 'min:6'] :
                ['required', 'confirmed', $this->strongPassword()],
            'password_confirmation' => 'required| min:6',
        ];
        $message = [
            'email.exists' => 'Email does not exist on record'
        ];
        $validateUser = Validator::make($request->all(), $rules,$message);
        if ($validateUser->fails()) {
            return response()->json($this->withError(collect($validateUser->errors())->collapse()));
        }
        $user = User::where('email', $request->email)->first();
        $user->password = Hash::make($request->password);
        $user->save();
        return response()->json($this->withSuccess('Password Updated'));
    }


private function handleCustomerResponse($response)
{
    // Check if the response status is true and details exist
    if (isset($response['original']['status']) && $response['original']['status'] === true) {
        $customerDetails = $response['original']['message']['details'];

        // Extract details
        $customerId = $customerDetails['customer_id'] ?? null;
        $firstName = $customerDetails['first_name'] ?? null;
        $lastName = $customerDetails['last_name'] ?? null;
        $email = $customerDetails['email'] ?? null;
        $phone = $customerDetails['phone'] ?? null;
        $country = $customerDetails['country'] ?? null;
        $tier = $customerDetails['tier'] ?? null;
        $createdAt = $customerDetails['created_at'] ?? null;

        // Return or further process the details
        return response()->json([
            'status' => 'success',
            'customer' => [
                'customer_id' => $customerId,
                'first_name' => $firstName,
                'last_name' => $lastName,
                'email' => $email,
                'phone' => $phone,
                'country' => $country,
                'tier' => $tier,
                'created_at' => $createdAt,
            ],
        ]);
    }

    // Handle the error case
    return response()->json([
        'status' => 'error',
        'message' => $response,
    ]);
}


}
